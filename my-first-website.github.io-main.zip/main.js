function aboutBtn() {
  window.scrollTo(0, 5000);
}

function contactBtn() {
  window.scrollTo(0, 5000);
}